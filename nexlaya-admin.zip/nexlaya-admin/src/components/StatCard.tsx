"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

export function StatCard({
  title,
  value,
  subtitle,
  icon: Icon,
  accent = "indigo",
}: {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: React.ComponentType<{ className?: string }>;
  accent?: "indigo" | "emerald" | "amber" | "red" | "sky";
}) {
  const accents: Record<string, string> = {
    indigo: "bg-indigo-600/20 text-indigo-300",
    emerald: "bg-emerald-600/20 text-emerald-300",
    amber: "bg-amber-600/20 text-amber-300",
    red: "bg-red-600/20 text-red-300",
    sky: "bg-sky-600/20 text-sky-300",
  };
  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-slate-400">{title}</p>
          <p className="text-2xl font-bold text-slate-100 mt-1">{value}</p>
          {subtitle && (
            <p className="text-xs text-slate-500 mt-1">{subtitle}</p>
          )}
        </div>
        {Icon && (
          <div className={cn("p-2 rounded-lg", accents[accent])}>
            <Icon className="h-5 w-5" />
          </div>
        )}
      </div>
    </div>
  );
}
