"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

type BadgeVariant = "default" | "success" | "warning" | "danger" | "info";

const variants: Record<BadgeVariant, string> = {
  default: "bg-slate-700 text-slate-100",
  success: "bg-emerald-600/20 text-emerald-300 border border-emerald-700/40",
  warning: "bg-amber-600/20 text-amber-300 border border-amber-700/40",
  danger: "bg-red-600/20 text-red-300 border border-red-700/40",
  info: "bg-indigo-600/20 text-indigo-300 border border-indigo-700/40",
};

export function Badge({
  className,
  variant = "default",
  ...props
}: React.HTMLAttributes<HTMLSpanElement> & { variant?: BadgeVariant }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
        variants[variant],
        className
      )}
      {...props}
    />
  );
}
