"use client";

import { useRouter } from "next/navigation";
import { LogOut, UserCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { createSupabaseBrowserClient } from "@/lib/supabase-browser";
import { useAuth } from "@/hooks/use-auth";

export function Topbar() {
  const router = useRouter();
  const { user } = useAuth();

  const handleLogout = async () => {
    const supabase = createSupabaseBrowserClient();
    await supabase.auth.signOut();
    router.replace("/login");
    router.refresh();
  };

  return (
    <header className="h-16 shrink-0 border-b border-slate-800 bg-slate-950/70 backdrop-blur flex items-center justify-between px-6">
      <div className="md:hidden text-slate-100 font-semibold">Training Admin</div>
      <div className="flex-1" />
      <div className="flex items-center gap-3">
        <div className="hidden sm:flex items-center gap-2 text-sm text-slate-300">
          <UserCircle2 className="h-5 w-5 text-slate-400" />
          <span className="truncate max-w-[180px]">
            {user?.email ?? "Loading..."}
          </span>
        </div>
        <Button variant="outline" size="sm" onClick={handleLogout}>
          <LogOut className="h-4 w-4 mr-1.5" />
          Logout
        </Button>
      </div>
    </header>
  );
}
