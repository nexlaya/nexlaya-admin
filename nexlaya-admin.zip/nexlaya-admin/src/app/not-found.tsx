import Link from "next/link";

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 text-slate-100 p-6">
      <div className="text-center max-w-md">
        <p className="text-sm font-semibold text-indigo-400">404</p>
        <h1 className="mt-2 text-3xl font-bold">Page not found</h1>
        <p className="mt-3 text-slate-400">
          The page you're looking for doesn't exist or you don't have access to it.
        </p>
        <Link
          href="/dashboard"
          className="inline-block mt-6 px-5 py-2.5 rounded-md bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium"
        >
          Go to Dashboard
        </Link>
      </div>
    </div>
  );
}
