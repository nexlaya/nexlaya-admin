"use client";

import { Plus } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, THead, TBody, TR, TH, TD } from "@/components/ui/table";

const teachers = [
  { id: "T-01", name: "Dr. Layla Mansour", role: "Lecturer", subject: "Anatomy", phone: "+963-11-555-0101", status: "Active" },
  { id: "T-02", name: "Dr. Khalil Aziz", role: "Senior Lecturer", subject: "Pharmacology", phone: "+963-11-555-0102", status: "Active" },
  { id: "T-03", name: "Ms. Rana Habib", role: "Instructor", subject: "Lab Techniques", phone: "+963-11-555-0103", status: "On Leave" },
  { id: "T-04", name: "Mr. Sami Daoud", role: "Instructor", subject: "Radiology", phone: "+963-11-555-0104", status: "Active" },
];

export default function TeachersPage() {
  return (
    <div>
      <PageHeader
        title="Teachers"
        description="Faculty and instructors"
        actions={
          <Button>
            <Plus className="h-4 w-4 mr-1.5" /> Add Teacher
          </Button>
        }
      />

      <Table>
        <THead>
          <TR>
            <TH>ID</TH>
            <TH>Name</TH>
            <TH>Role</TH>
            <TH>Subject</TH>
            <TH>Phone</TH>
            <TH>Status</TH>
          </TR>
        </THead>
        <TBody>
          {teachers.map((t) => (
            <TR key={t.id}>
              <TD className="font-mono text-xs text-slate-400">{t.id}</TD>
              <TD className="font-medium text-slate-100">{t.name}</TD>
              <TD>{t.role}</TD>
              <TD>{t.subject}</TD>
              <TD className="text-slate-400">{t.phone}</TD>
              <TD>
                <Badge variant={t.status === "Active" ? "success" : "warning"}>
                  {t.status}
                </Badge>
              </TD>
            </TR>
          ))}
        </TBody>
      </Table>
    </div>
  );
}
