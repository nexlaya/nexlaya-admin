"use client";

import { useEffect, useState } from "react";
import {
  Users,
  GraduationCap,
  CreditCard,
  Wallet,
  TrendingUp,
  AlertCircle,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  CartesianGrid,
  Legend,
} from "recharts";
import { PageHeader } from "@/components/PageHeader";
import { StatCard } from "@/components/StatCard";
import { useAuth } from "@/hooks/use-auth";
import { formatCurrency } from "@/lib/utils";

const revenueData = [
  { month: "Jan", income: 12400, expense: 8200 },
  { month: "Feb", income: 15300, expense: 9100 },
  { month: "Mar", income: 17800, expense: 9800 },
  { month: "Apr", income: 16200, expense: 10500 },
  { month: "May", income: 19400, expense: 11200 },
  { month: "Jun", income: 22100, expense: 12800 },
];

const serviceData = [
  { name: "Nursing", value: 42 },
  { name: "Pharmacy", value: 28 },
  { name: "Lab Tech", value: 19 },
  { name: "Radiology", value: 11 },
];

const trendData = [
  { week: "W1", students: 4 },
  { week: "W2", students: 7 },
  { week: "W3", students: 9 },
  { week: "W4", students: 6 },
  { week: "W5", students: 12 },
  { week: "W6", students: 14 },
];

const COLORS = ["#6366f1", "#10b981", "#f59e0b", "#ef4444"];

export default function DashboardPage() {
  const { user } = useAuth();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  return (
    <div>
      <PageHeader
        title="Dashboard"
        description={`Welcome${user?.email ? `, ${user.email}` : ""}. Here is what is happening today.`}
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Students"
          value="100"
          subtitle="Active enrollments"
          icon={Users}
          accent="indigo"
        />
        <StatCard
          title="Total Teachers"
          value="14"
          subtitle="Across all programs"
          icon={GraduationCap}
          accent="sky"
        />
        <StatCard
          title="Monthly Income"
          value={formatCurrency(22100)}
          subtitle="June 2025"
          icon={CreditCard}
          accent="emerald"
        />
        <StatCard
          title="Net Profit"
          value={formatCurrency(9300)}
          subtitle="After all expenses"
          icon={Wallet}
          accent="amber"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-6">
        <div className="lg:col-span-2 rounded-xl border border-slate-800 bg-slate-900 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-semibold text-slate-100">
              Revenue Over Time
            </h3>
            <span className="text-xs text-slate-500 inline-flex items-center gap-1">
              <TrendingUp className="h-3.5 w-3.5 text-emerald-400" /> +12%
            </span>
          </div>
          <div className="h-72">
            {mounted && (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="month" stroke="#64748b" fontSize={12} />
                  <YAxis stroke="#64748b" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      background: "#0f172a",
                      border: "1px solid #1e293b",
                      borderRadius: 8,
                      color: "#e2e8f0",
                    }}
                  />
                  <Legend wrapperStyle={{ color: "#94a3b8", fontSize: 12 }} />
                  <Bar dataKey="income" fill="#6366f1" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="expense" fill="#ef4444" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
          <h3 className="text-base font-semibold text-slate-100 mb-4">
            Students per Service
          </h3>
          <div className="h-72">
            {mounted && (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={serviceData}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={50}
                    outerRadius={90}
                    paddingAngle={3}
                  >
                    {serviceData.map((_, i) => (
                      <Cell key={i} fill={COLORS[i % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      background: "#0f172a",
                      border: "1px solid #1e293b",
                      borderRadius: 8,
                      color: "#e2e8f0",
                    }}
                  />
                  <Legend wrapperStyle={{ color: "#94a3b8", fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-6">
        <div className="lg:col-span-2 rounded-xl border border-slate-800 bg-slate-900 p-5">
          <h3 className="text-base font-semibold text-slate-100 mb-4">
            Registration Trend
          </h3>
          <div className="h-64">
            {mounted && (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="week" stroke="#64748b" fontSize={12} />
                  <YAxis stroke="#64748b" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      background: "#0f172a",
                      border: "1px solid #1e293b",
                      borderRadius: 8,
                      color: "#e2e8f0",
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="students"
                    stroke="#10b981"
                    strokeWidth={2}
                    dot={{ fill: "#10b981", r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900 p-5">
          <h3 className="text-base font-semibold text-slate-100 mb-4 flex items-center gap-2">
            <AlertCircle className="h-4 w-4 text-amber-400" /> Outstanding
          </h3>
          <ul className="space-y-3 text-sm">
            <li className="flex justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-300">Ahmed Saleh</span>
              <span className="text-amber-300">{formatCurrency(450)}</span>
            </li>
            <li className="flex justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-300">Mariam Khaled</span>
              <span className="text-amber-300">{formatCurrency(320)}</span>
            </li>
            <li className="flex justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-300">Yousef Ali</span>
              <span className="text-amber-300">{formatCurrency(180)}</span>
            </li>
            <li className="flex justify-between">
              <span className="text-slate-300">Sara Hassan</span>
              <span className="text-amber-300">{formatCurrency(120)}</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
