"use client";

import { useState } from "react";
import { Plus, Search } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, THead, TBody, TR, TH, TD } from "@/components/ui/table";

const students = [
  { code: "STU-001", name: "Ahmed Saleh", service: "Nursing", gender: "Male", status: "Active" },
  { code: "STU-002", name: "Mariam Khaled", service: "Pharmacy", gender: "Female", status: "Active" },
  { code: "STU-003", name: "Yousef Ali", service: "Lab Tech", gender: "Male", status: "Finished" },
  { code: "STU-004", name: "Sara Hassan", service: "Radiology", gender: "Female", status: "Active" },
  { code: "STU-005", name: "Omar Tariq", service: "Nursing", gender: "Male", status: "Graduated" },
];

const statusVariant = (s: string) =>
  s === "Active" ? "info" : s === "Finished" ? "warning" : "success";

export default function StudentsPage() {
  const [query, setQuery] = useState("");
  const filtered = students.filter(
    (s) =>
      s.name.toLowerCase().includes(query.toLowerCase()) ||
      s.code.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div>
      <PageHeader
        title="Students"
        description="Manage all enrolled trainees"
        actions={
          <Button>
            <Plus className="h-4 w-4 mr-1.5" /> Add Student
          </Button>
        }
      />

      <div className="mb-4 flex items-center gap-3 max-w-sm">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
          <Input
            placeholder="Search by name or code..."
            className="pl-9"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
      </div>

      <Table>
        <THead>
          <TR>
            <TH>Code</TH>
            <TH>Name</TH>
            <TH>Service</TH>
            <TH>Gender</TH>
            <TH>Status</TH>
          </TR>
        </THead>
        <TBody>
          {filtered.length === 0 ? (
            <TR>
              <TD colSpan={5} className="text-center text-slate-500 py-8">
                No students found
              </TD>
            </TR>
          ) : (
            filtered.map((s) => (
              <TR key={s.code}>
                <TD className="font-mono text-xs text-slate-400">{s.code}</TD>
                <TD className="font-medium text-slate-100">{s.name}</TD>
                <TD>{s.service}</TD>
                <TD>{s.gender}</TD>
                <TD>
                  <Badge variant={statusVariant(s.status)}>{s.status}</Badge>
                </TD>
              </TR>
            ))
          )}
        </TBody>
      </Table>
    </div>
  );
}
