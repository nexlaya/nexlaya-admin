"use client";

import { Plus } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, THead, TBody, TR, TH, TD } from "@/components/ui/table";
import { formatDate } from "@/lib/utils";

const internships = [
  { id: "INT-01", student: "Ahmed Saleh", hospital: "Damascus General Hospital", start: "2025-05-01", end: "2025-08-01", progress: 65 },
  { id: "INT-02", student: "Mariam Khaled", hospital: "Al-Mouwasat Hospital", start: "2025-04-15", end: "2025-07-15", progress: 80 },
  { id: "INT-03", student: "Sara Hassan", hospital: "Tishreen Military Hospital", start: "2025-06-01", end: "2025-09-01", progress: 30 },
  { id: "INT-04", student: "Omar Tariq", hospital: "Children's Hospital", start: "2025-03-01", end: "2025-06-01", progress: 100 },
];

export default function InternshipsPage() {
  return (
    <div>
      <PageHeader
        title="Internships"
        description="Active and completed clinical placements"
        actions={
          <Button>
            <Plus className="h-4 w-4 mr-1.5" /> New Internship
          </Button>
        }
      />

      <Table>
        <THead>
          <TR>
            <TH>ID</TH>
            <TH>Student</TH>
            <TH>Hospital</TH>
            <TH>Start</TH>
            <TH>End</TH>
            <TH>Progress</TH>
            <TH>Status</TH>
          </TR>
        </THead>
        <TBody>
          {internships.map((i) => (
            <TR key={i.id}>
              <TD className="font-mono text-xs text-slate-400">{i.id}</TD>
              <TD className="font-medium text-slate-100">{i.student}</TD>
              <TD>{i.hospital}</TD>
              <TD>{formatDate(i.start)}</TD>
              <TD>{formatDate(i.end)}</TD>
              <TD className="w-40">
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-2 rounded-full bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-indigo-500"
                      style={{ width: `${i.progress}%` }}
                    />
                  </div>
                  <span className="text-xs text-slate-400 w-10 text-right">
                    {i.progress}%
                  </span>
                </div>
              </TD>
              <TD>
                <Badge variant={i.progress === 100 ? "success" : "info"}>
                  {i.progress === 100 ? "Completed" : "Active"}
                </Badge>
              </TD>
            </TR>
          ))}
        </TBody>
      </Table>
    </div>
  );
}
