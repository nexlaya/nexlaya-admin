"use client";

import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Plus } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

type Event = { date: string; title: string; type: "exam" | "meeting" | "intern" };

const events: Event[] = [
  { date: "2025-06-05", title: "Mid-term: Anatomy", type: "exam" },
  { date: "2025-06-10", title: "Faculty Meeting", type: "meeting" },
  { date: "2025-06-15", title: "Internship Review", type: "intern" },
  { date: "2025-06-22", title: "Final: Pharmacology", type: "exam" },
  { date: "2025-06-28", title: "Graduation Ceremony", type: "meeting" },
];

const typeVariant = (t: Event["type"]) =>
  t === "exam" ? "danger" : t === "meeting" ? "info" : "success";

function buildMonth(year: number, month: number) {
  const first = new Date(year, month, 1);
  const startWeekday = first.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells: (number | null)[] = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

export default function CalendarPage() {
  const [cursor, setCursor] = useState(new Date(2025, 5, 1));
  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const cells = useMemo(() => buildMonth(year, month), [year, month]);
  const monthLabel = cursor.toLocaleDateString("en-US", {
    month: "long",
    year: "numeric",
  });

  const eventsByDay = useMemo(() => {
    const map: Record<number, Event[]> = {};
    for (const e of events) {
      const d = new Date(e.date);
      if (d.getFullYear() === year && d.getMonth() === month) {
        const day = d.getDate();
        (map[day] ||= []).push(e);
      }
    }
    return map;
  }, [year, month]);

  return (
    <div>
      <PageHeader
        title="Calendar"
        description="Exams, meetings and internship events"
        actions={
          <Button>
            <Plus className="h-4 w-4 mr-1.5" /> Add Event
          </Button>
        }
      />

      <div className="rounded-xl border border-slate-800 bg-slate-900 overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-800">
          <h2 className="text-lg font-semibold text-slate-100">{monthLabel}</h2>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCursor(new Date(year, month - 1, 1))}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCursor(new Date(year, month + 1, 1))}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-7 text-xs text-slate-400 border-b border-slate-800">
          {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
            <div key={d} className="px-3 py-2 text-center font-medium">
              {d}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7">
          {cells.map((d, i) => (
            <div
              key={i}
              className="min-h-[110px] border-b border-r border-slate-800 p-2 last:border-r-0"
            >
              {d && (
                <>
                  <div className="text-xs text-slate-400">{d}</div>
                  <div className="mt-1 space-y-1">
                    {(eventsByDay[d] || []).map((e, idx) => (
                      <Badge
                        key={idx}
                        variant={typeVariant(e.type)}
                        className="block w-full truncate"
                      >
                        {e.title}
                      </Badge>
                    ))}
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
