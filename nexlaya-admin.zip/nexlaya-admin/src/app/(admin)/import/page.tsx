"use client";

import { useState } from "react";
import { Upload, FileText, CheckCircle2 } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";

export default function ImportPage() {
  const [file, setFile] = useState<File | null>(null);
  const [importing, setImporting] = useState(false);
  const [done, setDone] = useState(false);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0] ?? null;
    setFile(f);
    setDone(false);
  };

  const handleImport = async () => {
    if (!file) return;
    setImporting(true);
    setDone(false);
    // Simulate processing — wire to your API route when ready
    await new Promise((r) => setTimeout(r, 1200));
    setImporting(false);
    setDone(true);
  };

  return (
    <div>
      <PageHeader
        title="Import"
        description="Upload a DOCX or CSV file to bulk-import students"
      />

      <div className="rounded-xl border border-slate-800 bg-slate-900 p-6 max-w-2xl">
        <label
          htmlFor="file"
          className="flex flex-col items-center justify-center h-48 rounded-lg border-2 border-dashed border-slate-700 hover:border-indigo-500/60 hover:bg-slate-800/30 transition-colors cursor-pointer"
        >
          <Upload className="h-8 w-8 text-slate-500 mb-2" />
          <p className="text-sm text-slate-300">
            {file ? "Replace file" : "Click to choose a file"}
          </p>
          <p className="text-xs text-slate-500 mt-1">
            Supports .docx, .csv (max 10MB)
          </p>
          <input
            id="file"
            type="file"
            accept=".docx,.csv"
            className="hidden"
            onChange={handleFile}
          />
        </label>

        {file && (
          <div className="mt-4 flex items-center justify-between rounded-md border border-slate-800 bg-slate-950/40 px-4 py-3">
            <div className="flex items-center gap-3 min-w-0">
              <FileText className="h-5 w-5 text-indigo-400 shrink-0" />
              <div className="min-w-0">
                <p className="text-sm text-slate-100 truncate">{file.name}</p>
                <p className="text-xs text-slate-500">
                  {(file.size / 1024).toFixed(1)} KB
                </p>
              </div>
            </div>
            {done && (
              <span className="text-xs inline-flex items-center gap-1 text-emerald-400">
                <CheckCircle2 className="h-4 w-4" /> Imported
              </span>
            )}
          </div>
        )}

        <div className="mt-5 flex justify-end gap-2">
          <Button
            variant="outline"
            onClick={() => {
              setFile(null);
              setDone(false);
            }}
            disabled={!file || importing}
          >
            Reset
          </Button>
          <Button onClick={handleImport} disabled={!file || importing}>
            {importing ? "Importing..." : "Import"}
          </Button>
        </div>
      </div>

      <div className="mt-6 max-w-2xl rounded-xl border border-slate-800 bg-slate-900/60 p-5 text-sm text-slate-400">
        <p className="font-medium text-slate-200 mb-1">CSV format</p>
        <p>The first row must contain headers:</p>
        <code className="mt-2 block rounded-md bg-slate-950 px-3 py-2 text-xs text-slate-300 overflow-x-auto">
          full_name,student_code,gender,service,phone
        </code>
      </div>
    </div>
  );
}
