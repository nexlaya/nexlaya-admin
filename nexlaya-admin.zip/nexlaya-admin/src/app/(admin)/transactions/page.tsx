"use client";

import { Plus } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, THead, TBody, TR, TH, TD } from "@/components/ui/table";
import { StatCard } from "@/components/StatCard";
import { CreditCard, TrendingUp, TrendingDown, Wallet } from "lucide-react";
import { formatCurrency, formatDate } from "@/lib/utils";

const tx = [
  { id: "TX-1001", date: "2025-06-01", party: "Ahmed Saleh", type: "Tuition", amount: 450, status: "Confirmed" },
  { id: "TX-1002", date: "2025-06-03", party: "Mariam Khaled", type: "Tuition", amount: 380, status: "Confirmed" },
  { id: "TX-1003", date: "2025-06-04", party: "Electricity Bill", type: "Expense", amount: -210, status: "Confirmed" },
  { id: "TX-1004", date: "2025-06-06", party: "Dr. Layla Mansour", type: "Salary", amount: -1200, status: "Scheduled" },
  { id: "TX-1005", date: "2025-06-08", party: "Yousef Ali", type: "Tuition", amount: 500, status: "Confirmed" },
];

const typeVariant = (t: string) =>
  t === "Tuition" ? "success" : t === "Expense" ? "danger" : "warning";

export default function TransactionsPage() {
  return (
    <div>
      <PageHeader
        title="Transactions"
        description="All incoming and outgoing payments"
        actions={
          <Button>
            <Plus className="h-4 w-4 mr-1.5" /> New Transaction
          </Button>
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard title="Total Income" value={formatCurrency(22100)} icon={TrendingUp} accent="emerald" />
        <StatCard title="Total Expenses" value={formatCurrency(8400)} icon={TrendingDown} accent="red" />
        <StatCard title="Salaries" value={formatCurrency(4400)} icon={CreditCard} accent="amber" />
        <StatCard title="Net Profit" value={formatCurrency(9300)} icon={Wallet} accent="indigo" />
      </div>

      <Table>
        <THead>
          <TR>
            <TH>ID</TH>
            <TH>Date</TH>
            <TH>Party</TH>
            <TH>Type</TH>
            <TH className="text-right">Amount</TH>
            <TH>Status</TH>
          </TR>
        </THead>
        <TBody>
          {tx.map((t) => (
            <TR key={t.id}>
              <TD className="font-mono text-xs text-slate-400">{t.id}</TD>
              <TD>{formatDate(t.date)}</TD>
              <TD className="font-medium text-slate-100">{t.party}</TD>
              <TD>
                <Badge variant={typeVariant(t.type)}>{t.type}</Badge>
              </TD>
              <TD
                className={`text-right font-medium ${t.amount < 0 ? "text-red-300" : "text-emerald-300"}`}
              >
                {formatCurrency(t.amount)}
              </TD>
              <TD>
                <Badge variant={t.status === "Confirmed" ? "success" : "warning"}>
                  {t.status}
                </Badge>
              </TD>
            </TR>
          ))}
        </TBody>
      </Table>
    </div>
  );
}
