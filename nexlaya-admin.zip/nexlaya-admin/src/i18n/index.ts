"use client";

import i18n from "i18next";
import { initReactI18next } from "react-i18next";

const resources = {
  en: {
    translation: {
      appName: "Training Center Admin",
      dashboard: "Dashboard",
      students: "Students",
      teachers: "Teachers",
      transactions: "Transactions",
      internships: "Internships",
      calendar: "Calendar",
      import: "Import",
      logout: "Logout",
      login: "Login",
      email: "Email",
      password: "Password",
      signIn: "Sign In",
      welcome: "Welcome",
      totalStudents: "Total Students",
      totalTeachers: "Total Teachers",
      totalIncome: "Total Income",
      netProfit: "Net Profit",
      revenueOverTime: "Revenue Over Time",
      studentsPerService: "Students per Service",
      registrationTrend: "Registration Trend",
      noData: "No data found",
      loading: "Loading...",
    },
  },
  ar: {
    translation: {
      appName: "لوحة إدارة مركز التدريب",
      dashboard: "لوحة التحكم",
      students: "الطلاب",
      teachers: "المعلمون",
      transactions: "المعاملات المالية",
      internships: "التدريبات",
      calendar: "التقويم",
      import: "استيراد",
      logout: "تسجيل الخروج",
      login: "تسجيل الدخول",
      email: "البريد الإلكتروني",
      password: "كلمة المرور",
      signIn: "دخول",
      welcome: "مرحبا",
      totalStudents: "إجمالي الطلاب",
      totalTeachers: "إجمالي المعلمين",
      totalIncome: "إجمالي الدخل",
      netProfit: "صافي الربح",
      revenueOverTime: "الإيرادات عبر الزمن",
      studentsPerService: "الطلاب لكل برنامج",
      registrationTrend: "اتجاه التسجيل",
      noData: "لا توجد بيانات",
      loading: "جار التحميل...",
    },
  },
};

if (!i18n.isInitialized) {
  i18n.use(initReactI18next).init({
    resources,
    lng: "en",
    fallbackLng: "en",
    interpolation: { escapeValue: false },
  });
}

export default i18n;
