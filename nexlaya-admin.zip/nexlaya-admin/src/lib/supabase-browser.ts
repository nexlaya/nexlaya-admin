"use client";

import { createBrowserClient } from "@supabase/ssr";

export function createSupabaseBrowserClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !key) {
    // Don't crash the build — return a stub that throws only when used.
    // Vercel build runs without env vars in some setups; this keeps SSG safe.
    if (typeof window !== "undefined") {
      // eslint-disable-next-line no-console
      console.warn(
        "[supabase] Missing NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY"
      );
    }
    return createBrowserClient(
      url || "https://placeholder.supabase.co",
      key || "placeholder-anon-key"
    );
  }

  return createBrowserClient(url, key);
}
