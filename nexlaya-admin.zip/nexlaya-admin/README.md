# Nexlaya Admin — Training Center Backend

A private internal admin system built with **Next.js 14 (App Router) + Supabase Auth + TailwindCSS**.

## Features

- 🔐 Supabase Auth (email/password) — fully protected internal system
- 🚫 No public pages — every route requires authentication
- 📊 Dashboard with KPIs and charts
- 👨‍🎓 Students, 👩‍🏫 Teachers, 💰 Transactions, 🏥 Internships, 📅 Calendar, 📥 Import
- 🌗 Dark theme, responsive sidebar + topbar layout
- ☁️ Zero-config deploy on Vercel

## Local development

```bash
cp .env.example .env.local
# fill NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY
npm install
npm run dev
```

Open http://localhost:3000 — you'll be redirected to `/login`.

## Deploy to Vercel

1. Push this repo to GitHub.
2. Import it into Vercel (framework will auto-detect as **Next.js**).
3. Add the two env variables from `.env.example` in the Vercel project settings.
4. Deploy. Done — no 404, no extra config required.

## Auth flow

- `/` → redirects to `/dashboard` if logged in, else `/login`.
- `/login` → email/password form. On success → `/dashboard`.
- `(admin)/*` → middleware blocks anonymous users and redirects them to `/login`.
